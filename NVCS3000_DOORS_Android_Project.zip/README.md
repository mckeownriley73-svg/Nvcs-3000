# NVCS-3000 — Roblox DOORS style Android app

This is a fan-made scanner **simulation**. It does not connect to Roblox or detect entities in a live game.

## Build the APK using GitHub on Android

1. Create a new GitHub repository.
2. Upload the **contents** of this ZIP (keep the `.github` folder).
3. Open the repository's **Actions** tab.
4. Choose **Build NVCS-3000 APK** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run.
6. Scroll to **Artifacts** and download `NVCS3000-DOORS-APK`.
7. Extract the downloaded ZIP. The APK inside is `app-debug.apk`.
8. Tap the APK to install. Android may ask you to allow installs from your browser or file manager.

If GitHub's mobile page hides the Actions controls, open the browser menu and enable **Desktop site**.

## App features
- Green monochrome NVCS-style interface
- Simulated scan results
- DOORS-inspired entity database
- Threat-level labels and field notes
- System diagnostics

The APK produced by this workflow is a debug build for personal testing.
