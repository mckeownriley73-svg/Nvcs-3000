package com.example.nvcs3000

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.random.Random

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 13, 12)
    private val panel = Color.rgb(10, 28, 24)
    private val green = Color.rgb(80, 255, 160)
    private val pale = Color.rgb(190, 255, 218)
    private lateinit var result: TextView
    private lateinit var meter: TextView

    private data class Entity(val name: String, val threat: String, val note: String)
    private val entities = listOf(
        Entity("Rush", "HIGH", "A fast-moving entity. Hide when its approach is signalled."),
        Entity("Ambush", "CRITICAL", "A dangerous returning entity. Stay alert for repeated passes."),
        Entity("Eyes", "MEDIUM", "Avoid looking directly at it."),
        Entity("Screech", "MEDIUM", "Look around when you hear its distinctive sound."),
        Entity("Seek", "HIGH", "Keep moving and follow the route cues."),
        Entity("Figure", "CRITICAL", "Stay quiet and use hiding places when needed."),
        Entity("Dupe", "HIGH", "Check room details before entering.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("ROBLOX DOORS // FIELD EQUIPMENT", 12, green, true))
        page.addView(label("NVCS-3000", 34, pale, true).apply { setPadding(0, 8, 0, 0) })
        page.addView(label("NIGHT VISION & CREATURE SCANNER", 11, green, true))
        page.addView(space(22))

        val screen = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 18)
            setBackgroundColor(panel)
        }
        page.addView(screen)
        screen.addView(label("● SYSTEM ONLINE", 13, green, true))
        screen.addView(label("SCANNER READY", 22, pale, true).apply { setPadding(0, 12, 0, 6) })
        screen.addView(label("SECTOR: THE HOTEL     SIGNAL: STABLE", 10, green, false))
        screen.addView(space(18))
        meter = label("◉  NO ENTITY SIGNAL", 17, green, true)
        screen.addView(meter)
        result = label("Press SCAN AREA to run a local scanner simulation.", 14, pale, false)
        result.setPadding(0, 14, 0, 4)
        screen.addView(result)

        page.addView(space(16))
        page.addView(actionButton("⟲   SCAN AREA") { scan() })
        page.addView(space(10))
        page.addView(actionButton("▤   ENTITY DATABASE") { showDatabase() })
        page.addView(space(10))
        page.addView(actionButton("⌁   SYSTEM DIAGNOSTICS") {
            meter.text = "● ALL SYSTEMS NORMAL"
            result.text = "Optics: READY\nSignal processor: READY\nThreat database: LOADED\nMode: SIMULATION"
        })
        page.addView(space(20))
        page.addView(label("ENTITY DATABASE", 18, pale, true))
        page.addView(label("Known DOORS entities and field notes", 12, green, false))
        page.addView(space(8))
        entities.forEach { entity ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(panel)
            }
            card.addView(label(entity.name.uppercase(), 15, pale, true))
            card.addView(label("THREAT: ${entity.threat}", 11, green, true))
            card.addView(label(entity.note, 12, Color.LTGRAY, false))
            val lp = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 9 }
            page.addView(card, lp)
        }
        page.addView(space(8))
        page.addView(label("DISCLAIMER: This is a fan-made companion simulation. It does not connect to or detect activity inside Roblox.", 10, Color.GRAY, false))
    }

    private fun scan() {
        val e = entities[Random.nextInt(entities.size)]
        meter.text = "◉  SIGNAL DETECTED // ${e.threat}"
        result.text = "ENTITY: ${e.name.uppercase()}\nTHREAT LEVEL: ${e.threat}\n\nFIELD NOTE:\n${e.note}\n\nSCAN COMPLETE"
        Toast.makeText(this, "Scan complete", Toast.LENGTH_SHORT).show()
    }

    private fun showDatabase() {
        meter.text = "▤  DATABASE OPEN"
        result.text = entities.joinToString("\n") { "• ${it.name} — ${it.threat}" }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("monospace", Typeface.BOLD)
            else typeface = Typeface.create("monospace", Typeface.NORMAL)
        }

    private fun actionButton(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(green)
            textSize = 14f
            typeface = Typeface.create("monospace", Typeface.BOLD)
            setBackgroundColor(panel)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, height)
    }
}
